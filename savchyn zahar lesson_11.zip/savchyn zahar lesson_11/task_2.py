name = lambda name, surname: f'My name is {name.title()} {surname.title()}'
print(name('zahar', 'sauchyn'))